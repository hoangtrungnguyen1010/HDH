#include "syscall.h"
#define MAX_LENGTH 32

int main()
{
	int id;
	int size;
	char c; 
	char fileName[MAX_LENGTH];
	int i; 
	PrintString("\n\t\t\t-----HIEN THI NOI DUNG FILE-----\n\n");
	PrintString(" - Nhap vao ten file can doc: ");
	ReadString(fileName, MAX_LENGTH);
	id = Open(fileName, 1); // Goi ham Open de mo file 
	if (id != -1) {
		size = Seek(-1, id);
		i = 0;
		Seek(0, id);
		PrintString(" -> Noi dung file:\n");
		for (; i < size; i++) {
			Read(&c, 1, id); 
			PrintChar(c); 
		}
		Close(id); 
	}
	else {
		PrintString(" -> Mo file khong thanh cong!!\n\n");
	}
    Halt();
	return 0;
}