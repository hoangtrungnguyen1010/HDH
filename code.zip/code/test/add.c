#include "syscall.h"


int main()
{
  char name[10];
  int id;
  int res;
  ReadString(name, 10);
  PrintString(name);

  res = Remove(id);
  PrintNum(res);
  Halt();
  /* not reached */
}
