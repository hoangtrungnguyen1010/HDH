#include "syscall.h"


int main()
{
  char name[32];
  int id;
  int res;
  PrintString("Nhap ten file can xoa \n");
  ReadString(name, 32);
  res = Remove((char*)name);
  if (res==0){
      PrintString("Xoa file thanh cong \n");
  }
  else {
      PrintString("Xoa file that bai \n");
  }

  Halt();
  /* not reached */
}
