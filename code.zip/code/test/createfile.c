#include "syscall.h"
#define MAX_LENGTH 32


int main()
{
  char name[MAX_LENGTH];
  int res;
  PrintString("Nhap ten file thanh cong \n");
  ReadString(name, MAX_LENGTH);
  res = Create((char*)name);
  if (res==0){
    PrintString("Tao file thanh cong \n");
  }
  else{
    PrintString("Tao file that bai \n");
  }
  Halt();
  /* not reached */
}
