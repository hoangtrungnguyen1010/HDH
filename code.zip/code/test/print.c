#include "syscall.h"
int main()
{
    const len = 10;
    char a[len+1];
    int b,c;
    // a = "hihi";
    ReadString(a, len);
    PrintString(a);
    PrintChar('\n');
    ReadString(a, len);
    PrintString(a);
    PrintChar('\n');

    b = ReadNum();
    c = ReadNum();

    PrintNum(b);
    PrintChar('\n');
    PrintNum(c);
    PrintChar('\n');


    Halt();
}