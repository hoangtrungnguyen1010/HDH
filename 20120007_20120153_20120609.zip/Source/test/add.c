/* add.c
 *	Simple program to test whether the systemcall interface works.
 *	
 *	Just do a add syscall that adds two values and returns the result.
 *
 */

#include "syscall.h"
// #include "stdlib.h"
int
main()
{
    int b = RandomNum();
    PrintNum(b);
  Halt();
  /* not reached */
}
