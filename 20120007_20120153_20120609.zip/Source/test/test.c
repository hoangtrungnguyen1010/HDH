#include "syscall.h"

void printAscii (int c) {
    PrintString ("Ky tu co ma ascii ");
    PrintNum(c);
    PrintString(" :");
    PrintChar ((char)c);
    PrintChar('\n');
}

void printAsciiTable(){
    int i =0;
    for (; i< 128;i++){
        printAscii(i);
    }
}
int decrease (int a, int b) {
    return a < b ? 0 : 1;
}
int increase (int a, int b) {
    return a < b ? 1 : 0;
}
void bubbleSort (int a[], int n, int(*check)(int, int)) {
    int i, j, tmp;
    for (i = 0; i < n; i++) {
        for (j = 0; j < (n-1); j++) {
            if (check(a[j], a[j + 1]) == 0) {	
                tmp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = tmp;
            }
        }
    }
}

void help () {
    PrintString("20120007 - Do Trung Hieu\n");
    PrintString("20120153 - Pham Thi Quynh Nhu\n");
    PrintString("20120609 - Nguyen Hoang Trung\n");
    PrintString("De in bang ky tu, goi ham \'printAsciiTale() trong ham main\'\n");
    PrintString("De sap xep mang bang bubble sort, goi ham \'bubbleSort()\', cac tham so truyen vao lan luot la ten mang can sort, kich thuoc mang, thu tu nguoi dung muon sap xep\n");

}

int main(){
    int i = 0;
    int a[8] = {5, 4, 0, 2, 1, 2, 5, 10};
    help();
    bubbleSort(a, 8, decrease);
    for (; i < 8; i++) {
        PrintNum (a[i]);
        PrintChar('\n');
    }
    printAsciiTable();
    Halt();
}